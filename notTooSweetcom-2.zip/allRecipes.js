var button = $("button");
var message = $(".message"):

button.on("click",yippee);

function yippee() {
  event.preventDefault();
  alert(`Thank you for using our site! Your feedback has been accepted!`);
}

ma